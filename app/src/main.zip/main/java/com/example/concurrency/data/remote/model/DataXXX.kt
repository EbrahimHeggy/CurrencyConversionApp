package com.example.concurrency.data.remote.model


//What I will get
data class DataXXX(
    val base: String,
    val currencies: List<Currency>
)