package com.example.concurrency.data.remote.model

data class Data(
    val amount: Double,
    val destination: String,
    val source: String
)