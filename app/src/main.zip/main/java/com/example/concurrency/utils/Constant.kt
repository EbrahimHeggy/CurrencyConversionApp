package com.example.concurrency.utils

object Constant {


    const val BASE_URL = "https://graduationprojectbm.up.railway.app/api/v1/"
}