package com.example.concurrency.data.remote.model



data class FavoriteResponse(
    val data: DataXXX,
    val isSuccess: Boolean,
    val statusCode: Int
)