package com.example.concurrency.data.remote.model

data class DataXX(
    val amount1: Double,
    val amount2: Double,
    val destination1: String,
    val destination2: String,
    val source: String
)